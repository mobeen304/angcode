import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-added',
  templateUrl: './card-added.component.html',
  styleUrls: ['./card-added.component.scss']
})
export class CardAddedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
