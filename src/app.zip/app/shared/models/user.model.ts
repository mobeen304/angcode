export class User {
    constructor(
        public Username: string,
        public Password: string,
        public Password2: string,
        public Remember: boolean,
    ){}
}
