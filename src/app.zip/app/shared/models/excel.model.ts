export class Excel {
    constructor(
        public Id: string,
        public Name: string,
        public Variables: Array<any>
    ){}
}