export class Stock {
    constructor(
        public Stock: string,
        public Symbol: string,
        public LatestPrice: string,
        public PercentChange: string,
        public Popularity: string
    ){}
}