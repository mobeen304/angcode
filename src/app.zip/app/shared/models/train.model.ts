export class Train {
    constructor(
        public Resutl: string,
        public Test: string,
        
        
    ){}
}