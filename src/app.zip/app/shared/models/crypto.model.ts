export class Crypto {
    constructor(
        public Currency: string,
        public LatestPrice: string,
        public PercentChange: string,
        public Popularity: string,
        public Symbol: string
    ){}
}